package com.emeralddb.base;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class EdbPopupMenu extends JPopupMenu {
	public EdbPopupMenu() {
		//super();
		super.removeAll();
		super.add( new JMenuItem("save as picture...") );
	}
}
